backButton = document.getElementById('back');
// back button
backButton.addEventListener('click',function(){
    window.location = 'B:\\tnc-company-projects\\company-website\\bootsrap-website\\html.pages\\offerredServices.html'
  })