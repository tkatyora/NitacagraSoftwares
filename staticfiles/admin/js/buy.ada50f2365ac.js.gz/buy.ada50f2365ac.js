let cancel = document.getElementById('cancel');

    console.log(cancel)
    cancel.addEventListener('click',function(){
      alert(' You about to cancel the process');
      window.location = 'B:\\tnc-company-projects\\company-website\\bootsrap-website\\html.pages\\offerredServices.html'
    } )
    
    
 
